import pygame

class Display:
    def __init__(self, ancho, alto, titulo, fps, tam_celda):
        self.__ancho = ancho
        self.__alto = alto
        self.__titulo = titulo
        self.__fps = fps
        self.__tam_celda = tam_celda
    

    def set_display(self):

        pygame.init()
        self.__pantalla = pygame.display.set_mode((self.__ancho, self.__alto))
        pygame.display.set_caption(self.__titulo)
        self.reloj = pygame.time.Clock()

    def dibujar_grid(self, color = (0,0,0)):
        # Dibujar líneas verticales
        for x in range(0, self.__ancho, self.__tam_celda):
            pygame.draw.line(self.__pantalla, color, (x, 0), (x, self.__alto))
    
        # Dibujar líneas horizontales
        for y in range(self.__tam_celda, self.__alto, self.__tam_celda):
            pygame.draw.line(self.__pantalla, color, (0, y), (self.__ancho, y))

    def pos_grid(self, x,y):
        posX = x * self.__tam_celda + self.__tam_celda // 2 + 1 
        posY = y * self.__tam_celda + self.__tam_celda // 2 + 1
        return (posX, posY) 

    # FUNCIONES GET 

    def get_fps(self):
        return self.__fps
    
    @property
    def get_pantalla(self):
        return self.__pantalla
    
    def get_tam_celda(self):
        return self.__tam_celda
    
    def get_alto(self):
        return self.__alto

    def get_ancho(self):
        return self.__ancho
    
    # FUNCIONES SET

    def set_fps(self, fps):
        self.__fps = fps

    def set_tam_celda(self, tam_celda):
        self.__tam_celda = tam_celda
    
    def set_ancho(self, ancho):
        self.__ancho = ancho
    
    def set_alto(self, alto):
        self.__alto = alto
