import pygame
from Object import Object

class Player(Object):
    def __init__(self, x, y, ancho, alto, image=None, color = (255,0,0)):
        super().__init__(x, y, ancho, alto, image, color)

    def control_manual(self, event, VELOCIDAD, dx, dy):     
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                dx, dy = -VELOCIDAD, 0
            if event.key == pygame.K_RIGHT:
                dx, dy = VELOCIDAD, 0

        return dx, dy

    