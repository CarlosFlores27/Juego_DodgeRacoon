import pygame
import sys
import random
from Player import Player
from Display import Display
from Object import Object

ANCHO = 540
ALTO = 660
TAM_CELDA = 60
FPS = 60

def main():

    juego = Display(ANCHO, ALTO, 'DodgeRacoon', FPS, TAM_CELDA)
    juego.set_display()
    icono = pygame.image.load("racoon.png")  
    pygame.display.set_icon(icono)
    
    NUEVO_OBJETO = pygame.USEREVENT + 1  
    pygame.time.set_timer(NUEVO_OBJETO, 1000) 

    racoon = Player(random.randint(0, ANCHO//TAM_CELDA-1), ALTO // TAM_CELDA - 2, TAM_CELDA , TAM_CELDA , 'racoon.png')

    objetos = []

    VELOCIDAD = 0.1
    vObjeto = 0.2
    dx, dy = 0,0
    status = -1
    fondo = pygame.image.load("background.jpg").convert()
    fondo = pygame.transform.scale(fondo, (ANCHO, ALTO + 2* TAM_CELDA))
    fondoOver = pygame.image.load("over.jpg").convert()
    fondoOver = pygame.transform.scale(fondoOver, (ANCHO, ALTO))
 
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
            dx, dy = racoon.control_manual(event, VELOCIDAD, dx, dy)

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()

            if event.type == NUEVO_OBJETO:
                nuevo = Object(
                    random.randint(0, ANCHO//TAM_CELDA - 1),
                    -2,
                    TAM_CELDA, TAM_CELDA, 'trash.png'
                )
                
                objetos.append(nuevo)

        X, _ = racoon.get_pos()

        if X + dx >= 0 and X + dx <= juego.get_ancho() // juego.get_tam_celda() -1: 
            racoon.mover(dx, 0)
        
        for objeto in objetos[:]:
            objeto.mover(0, vObjeto) 

            if racoon.rect.colliderect(objeto.rect):
                status +=1
                if status == 1:
                    juego.get_pantalla.blit(fondoOver, (0, 0))
                    pygame.display.flip()
                    pygame.time.delay(2000)  
                    pygame.quit()
                    sys.exit()

            if objeto.rect.y > ALTO - 2 *TAM_CELDA:
                objetos.remove(objeto)
        
        juego.get_pantalla.fill((173, 216, 240))
        juego.get_pantalla.blit(fondo, (0, 0))

        racoon.dibujar(juego)

        for objeto in objetos:
            objeto.dibujar(juego)

        pygame.display.flip()
        juego.reloj.tick(juego.get_fps())

if __name__ == "__main__":
    main()
